package project;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;


public class Task1_TravelInsurance {
    WebDriver driver;

    public Task1_TravelInsurance(WebDriver driver) {
        this.driver = driver;
    }

    public void firstPage() {
        driver.findElement(By.xpath("/html/body/main/div[2]/section/div[7]/a/div[1]/div")).click();
    }

    public void secondPage() {
        driver.findElement(By.xpath("//*[@id=\"favourite-country\"]/li[4]/picture")).click();
        driver.findElement(By.xpath("//*[@id=\"newPq_mainWrapper\"]/section/section[2]/article[2]/div[1]")).click();
    }

    public void dateSelection() throws InterruptedException {
        WebElement drag = driver.findElement(By.xpath("//*[@id=\"modal-root\"]/section/article/div/div/div[2]/div[2]/div/div/div/div[3]/div/div[4]/div[6]/div/button"));
        WebElement drop = driver.findElement(By.xpath("//*[@id=\"modal-root\"]/section/article/div/div/div[2]/div[2]/div/div/div/div[3]/div/div[4]/div[7]/div/button"));
        drag.click();
        Thread.sleep(3000);
        drop.click();
        Thread.sleep(2000);
        driver.findElement(By.xpath("//*[@id=\"modal-root\"]/section/article/div/div/div[2]/div[3]/div/button")).click();
    }

    public void formFillers() throws InterruptedException {
    	driver.findElement(By.xpath("//*[@id=\"modal-root\"]/section/article/div/div/div[2]/div[1]/div[1]/div[2]/label")).click();
		
		driver.findElement(By.xpath("//*[@id=\"divarrow_undefined\"]/div")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"optionBox_0_wrapper\"]/div[24]/label")).click();
		
		driver.findElement(By.xpath("/html/body/section[2]/section/article/div/div/div[2]/div[1]/div[2]/div[2]/div/div/div/div")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"optionBox_1_wrapper\"]/div[23]/label")).click();
		driver.findElement(By.id("ped_no")).click();
		driver.findElement(By.xpath("//*[@id=\"modal-root\"]/section/article/div/div/div[2]/div[3]/div/button")).click();
    }

    public void viewPlans() {
    	try {
    		WebElement plans=driver.findElement(By.xpath("//*[@id=\"newPq_mainWrapper\"]/section/section[2]/div/button"));
    		plans.click();
    	}catch(Exception e) {
    		System.out.println("Element is not clickable");
    	}
    }

    public void navigateBackToHome() {
    	driver.findElement(By.xpath("//*[@id=\"newPq_mainWrapper\"]/div/div/a[2]")).click();
    }
}

package project;

import java.io.File;
import java.time.Duration;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

public class Task2_CarInsurance {
    WebDriver driver;

    public Task2_CarInsurance(WebDriver driver) {
        this.driver = driver;
    }

    public void firstCarPage() {
        driver.findElement(By.xpath("/html/body/main/div[2]/section/div[4]")).click();
    }

    public void withoutCarNumber() {
        driver.findElement(By.xpath("/html/body/section/section/div[1]/div/div/div[2]/div/div[3]/div/span")).click();
    }

    public void cityChoose() {
        driver.findElement(By.xpath("/html/body/section/section/div/div/div/div[2]/div[2]/div/div/ul[1]/li[11]")).click();
    }

    public void carBrandChoose() {
        driver.findElement(By.xpath("/html/body/section/section/div/div/div/div[2]/div[2]/div[3]/ul/li[2]")).click();
    }

    public void carModelAndFuel() throws InterruptedException {
        driver.findElement(By.xpath("/html/body/section/section/div/div/div/div[2]/div[2]/div[3]/ul/li[1]")).click();
        Thread.sleep(2000);
        driver.findElement(By.xpath("/html/body/section/section/div/div/div/div[2]/div[2]/div/ul/li[1]")).click();
    }

    public void carVariant() {
        driver.findElement(By.xpath("/html/body/section/section/div/div/div/div[2]/div[2]/div[3]/ul/li[1]")).click();
    }

    public void lastDetails() {
        driver.findElement(By.id("name-form-control")).sendKeys("Swayam");
        driver.findElement(By.id("mobile-form-control")).sendKeys("81982134");
    }
    
    public File screenshot1() throws Exception{
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		TakesScreenshot ss=(TakesScreenshot) driver;
		File fs=ss.getScreenshotAs(OutputType.FILE);
		File trg = new File("Screenshot/ss1.png");
		FileUtils.copyFile(fs, trg);
		return fs;
	}

    public void backToHome() {
        driver.findElement(By.xpath("/html/body/section/header/div/div/div[1]/a/img")).click();
    }
}

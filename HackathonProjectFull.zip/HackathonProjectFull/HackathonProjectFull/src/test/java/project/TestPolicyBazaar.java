package project;

import java.io.File;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.*;

public class TestPolicyBazaar {
    WebDriver driver;
    Task1_TravelInsurance travel;
    Task2_CarInsurance car;
    Task3_HealthInsurance health;

    @BeforeClass
    public void setup() {
        driver = DriverSetup.getDriver();
        driver.manage().window().maximize();
        driver.get("https://www.policybazaar.com");

        travel = new Task1_TravelInsurance(driver);
        car = new Task2_CarInsurance(driver);
        health = new Task3_HealthInsurance(driver);
    }

    @Test(priority = 1)
    public void travelInsuranceFlow() throws Exception {
        travel.firstPage();
        Thread.sleep(2000);
        travel.secondPage();
        Thread.sleep(3000);
        travel.dateSelection();
        Thread.sleep(2000);
        travel.formFillers();
        Thread.sleep(2000);
        travel.viewPlans();
        Thread.sleep(2000);
        Assert.assertTrue(driver.getCurrentUrl().contains("travel"), "Travel Insurance flow failed to reach plans page.");
        travel.navigateBackToHome();
        Thread.sleep(2000);
    }

    @Test(priority = 2)
    public void carInsuranceFlow() throws Exception {
        car.firstCarPage();
        Thread.sleep(2000);
        car.withoutCarNumber();
        Thread.sleep(2000);
        car.cityChoose();
        Thread.sleep(3000);
        car.carBrandChoose();
        Thread.sleep(2000);
        car.carModelAndFuel();
        Thread.sleep(2000);
        car.carVariant();
        Thread.sleep(2000);
        car.lastDetails();
        Thread.sleep(2000);
        Assert.assertTrue(driver.getPageSource().contains("Car"), "Car Insurance page does not contain expected content.");
        File ss1=car.screenshot1();
		System.out.println(ss1);
		Thread.sleep(2000);
        car.backToHome();
        Thread.sleep(2000);
    }

    @Test(priority = 3)
    public void healthInsuranceFlow() throws Exception {
        health.healthInsurance();
        Thread.sleep(2000);
        health.ageSelection();
        Thread.sleep(2000);
        health.selectCity();
        Thread.sleep(2000);
        File screenshot = health.details();
        Assert.assertTrue(screenshot.exists(), "Screenshot for Health Insurance form was not saved.");
    }

    @AfterClass
    public void tearDown() {
        driver.quit();
    }
}

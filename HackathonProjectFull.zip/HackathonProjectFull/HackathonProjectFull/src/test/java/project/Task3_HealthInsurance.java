package project;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

public class Task3_HealthInsurance {
    WebDriver driver;

    public Task3_HealthInsurance(WebDriver driver) {
        this.driver = driver;
    }

    public void healthInsurance() throws InterruptedException {
    	Actions action=new Actions(driver);
		
		driver.findElement(By.xpath("/html/body/main/div[2]/section/div[2]/a/div[1]")).click();
		Thread.sleep(2000);

		action.scrollByAmount(0, 500).perform();
		
		driver.findElement(By.id("step1ContinueBtn")).click();
    }

    public void ageSelection() {
    	WebElement dropdown=driver.findElement(By.id("Self"));
		Select select=new Select(dropdown);
		select.selectByContainsVisibleText("18");
		
		driver.findElement(By.id("step2ContinueBtn")).click();
    }

    public void selectCity() {
		WebElement search=driver.findElement(By.id("city"));
		search.sendKeys("kanpur");
		
		driver.findElement(By.xpath("//*[@id=\"foundCityContainer\"]/ul/li[2]")).click();
		
//		driver.findElement(By.id("step3ContinueBtn")).click();
    }

    public File details() throws InterruptedException, IOException {
        driver.findElement(By.xpath("//*[@id='fullName']")).sendKeys("Swayam");
        WebElement mobno = driver.findElement(By.xpath("//*[@id=\"mobile\"]"));
        mobno.sendKeys("8108192834");
        driver.findElement(By.id("step4ContinueBtn")).click();
        Thread.sleep(2000);
        try {
            Alert alert = driver.switchTo().alert();
            alert.dismiss();
        } catch (NoAlertPresentException e) {}
        File fs = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
        File trg = new File("Screenshot/ss2.png");
        FileUtils.copyFile(fs, trg);
        return fs;
    }
}
